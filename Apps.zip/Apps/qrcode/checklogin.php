<?php
	include "conn.php";
	$result=array();
	$result["hasil"]="no";
	$username=mysqli_real_escape_string($conn,$_GET["username"]);
	$password=mysqli_real_escape_string($conn,$_GET["password"]);
	$q="SELECT * FROM siswa WHERE Username='$username' AND Password='$password'";
	//echo $q;
	$res=mysqli_query($conn,$q);
	if ($row=mysqli_fetch_assoc($res))
	{
		$result["user"]=$row;
		$result["hasil"]="ok";
	}
	echo json_encode($result);
?>
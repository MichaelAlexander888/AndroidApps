<?php
	header("Access-Control-Allow-Origin: *");
	$conn = new mysqli("localhost", "root", "", "qrabsen");
?>
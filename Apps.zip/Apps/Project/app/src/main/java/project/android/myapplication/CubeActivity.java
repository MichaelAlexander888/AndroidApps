package project.android.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;


import java.io.File;

public class CubeActivity extends AppCompatActivity {

    public static Bitmap aBitmap[];
     @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        aBitmap=new Bitmap[6];
         com.google.zxing.Writer writer = new QRCodeWriter();
         // String finaldata = Uri.encode(data, "utf-8");
         int width = 250;
         int height = 250;
         try {
             for (int i=0;i<6;i++)
             {
                 BitMatrix bm = writer
                         .encode(i+"_"+Util.user.getString("NRP"), BarcodeFormat.QR_CODE, width, height);
                 Bitmap ImageBitmap = Bitmap.createBitmap(width, height,
                         Bitmap.Config.ARGB_8888);
                 for (int ix = 0; ix < width; ix++) {// width
                     for (int jx = 0; jx < height; jx++) {// height
                         ImageBitmap.setPixel(ix, jx, bm.get(ix, jx) ? Color.BLACK
                                 : Color.WHITE);
                     }
                 }
                 aBitmap[i]=ImageBitmap;
             }
         }
         catch (Exception ex)
         {
            ex.printStackTrace();
         }




        setContentView(R.layout.activity_cube);
        getSupportActionBar().hide();

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        GLSurfaceView view = new GLSurfaceView(this);
        view.setRenderer(new OpenGLRenderer(getApplicationContext()));
        setContentView(view);
    }
}

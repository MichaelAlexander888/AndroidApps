package project.android.myapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.icu.text.SimpleDateFormat;
import android.os.Environment;

import org.json.JSONObject;

import java.io.File;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Date;
import java.util.Random;

public class Util {
    public static JSONObject user;
    public static String ip="http://tos.petra.ac.id/~m26414118/";




    public final static boolean isValidEmail(CharSequence target) {
        if (target == null)
            return false;

        return android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }

    public static String userID="";
    public static String randomNama() {
        //String generatedString = RandomStringUtils.randomAlphabetic(10);
        //return generatedString;
        //System.out.println(generatedString);
        long millis=System.currentTimeMillis();
        Random rand = new Random();
        return millis+""+rand.nextInt(10000);
    }

    static int maxWidth=800;
    static int maxHeight=600;
    public static Bitmap getResizedBitmap2(Bitmap bm) {
        int newWidth=0;
        int newHeight=0;
        boolean needResize=false;
        if (bm.getWidth()>maxWidth || bm.getHeight()>maxHeight)
        {
            needResize=true;
            if (bm.getWidth()>bm.getHeight())
            {
                newWidth=maxWidth;
                newHeight=(int)((maxWidth*1.0)/bm.getWidth()*bm.getHeight());
            }
            else if (bm.getHeight()>bm.getWidth())
            {
                newHeight=maxHeight;
                newWidth=(int)((maxHeight*1.0)/bm.getHeight()*bm.getWidth());
            }
        }

        int width = bm.getWidth();
        int height = bm.getHeight();
        if (needResize) {


            float scaleWidth = ((float) newWidth) / width;
            float scaleHeight = ((float) newHeight) / height;


            // CREATE A MATRIX FOR THE MANIPULATION
            Matrix matrix = new Matrix();
            // RESIZE THE BIT MAP
            matrix.postScale(scaleWidth, scaleHeight);

            // "RECREATE" THE NEW BITMAP
            Bitmap resizedBitmap = Bitmap.createBitmap(
                    bm, 0, 0, width, height, matrix, false);
            bm.recycle();
            return resizedBitmap;
        }
        else {
            return bm;
        }
    }

    public static Bitmap getResizedBitmap(Bitmap bm) {
        int newWidth=100;
        int newHeight=100;
        int width = bm.getWidth();
        int height = bm.getHeight();
        float scaleWidth = ((float) newWidth) / width;
        float scaleHeight = ((float) newHeight) / height;
        // CREATE A MATRIX FOR THE MANIPULATION
        Matrix matrix = new Matrix();
        // RESIZE THE BIT MAP
        matrix.postScale(scaleWidth, scaleHeight);
        // "RECREATE" THE NEW BITMAP
        Bitmap resizedBitmap = Bitmap.createBitmap(
                bm, 0, 0, width, height, matrix, false);
        bm.recycle();
        return resizedBitmap;

    }

    public static String getnumber(int number)
    {
        DecimalFormatSymbols symbols = DecimalFormatSymbols.getInstance();
        DecimalFormat formatter = new DecimalFormat("###,###.##", symbols);
        return formatter.format(number);
    }
}

package project.android.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.ArrayList;

public class HistoryActivity extends AppCompatActivity {
    ListView lvHistory;
    HistoryAdapter ha;
    ArrayList<JSONObject> daftar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        getSupportActionBar().hide();
        lvHistory=(ListView)findViewById(R.id.lvHistory);
        daftar=new ArrayList<JSONObject>();
        ha=new HistoryAdapter(getApplicationContext(),daftar);
        lvHistory.setAdapter(ha);
        loadHistory();
    }
    void loadHistory() {
        try {

            String url = "";
            AsyncResponse ar = new AsyncResponse() {
                @Override
                public void execute(String s) {
                    try {
                        JSONArray hasil = new JSONArray(s);
                        daftar.clear();
                        for (int i=0;i<hasil.length();i++)
                        {
                            daftar.add(hasil.getJSONObject(i));
                        }
                        ha.notifyDataSetChanged();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            };
            NetworkTask nt = new NetworkTask(HistoryActivity.this, "Informasi", "Memuat Data History", ar, false, null);
            MainActivity.loadToken(getApplicationContext());
            url = Util.ip + "process.php?nrp=" + Util.user.getString("NRP");
            System.out.println(url);
            nt.execute(url);
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Gagal");
        }
    }
}

package project.android.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONObject;

import java.net.URLEncoder;

public class MainActivity extends AppCompatActivity {
    EditText etUsername;
    EditText etPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUsername=(EditText)findViewById(R.id.etUsername);
        etPassword=(EditText)findViewById(R.id.etPassword);

        etUsername.setText("");
        etPassword.setText("");

        getSupportActionBar().hide();
    }



    public void login(View v)
    {
        try {

            String url="";
            AsyncResponse ar=new AsyncResponse() {
                @Override
                public void execute(String s) {
                    try
                    {
                        JSONObject hasil=new JSONObject(s);
                        if (hasil.getString("hasil").equals("ok"))
                        {
                            Util.user=hasil.getJSONObject("user");
                            Intent it=new Intent(getApplicationContext(),MenuUtamaActivity.class);
                            startActivity(it);
                        }
                        else {
                            Toast.makeText(getApplicationContext(),"Username dan Password yang anda masukkan salah",Toast.LENGTH_LONG).show();
                        }
                    }
                    catch (Exception ex)
                    {
                        ex.printStackTrace();
                    }
                }
            };
            NetworkTask nt=new NetworkTask(MainActivity.this, "Informasi", "Melakukan Login", ar,false,null);
            MainActivity.loadToken(getApplicationContext());
            String username= URLEncoder.encode(etUsername.getText().toString(),"utf-8");
            String password= URLEncoder.encode(etPassword.getText().toString(),"utf-8");

            url=Util.ip+"checklogin.php?username="+username+"&password="+password+"&token="+ MainActivity.token;
            System.out.println(url);
            nt.execute(url);
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            System.out.println("Gagal");
        }
    }
    public static String token;
    public static void saveToken(Context ctx)
    {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(ctx);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("token",token);
        editor.apply();

    }
    public static void loadToken(Context ctx)
    {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(ctx);
        token=preferences.getString("token","");

    }

}

package project.android.myapplication;


import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;


import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class HistoryAdapter extends BaseAdapter {

    public String tipe="";
    private Context context;
    private ArrayList<JSONObject> daftarJadwal;

    public HistoryAdapter(Context context, ArrayList<JSONObject> daftarJadwal) {
        this.context = context;
        this.daftarJadwal = daftarJadwal;
    }

    @Override
    public int getCount() {
        return daftarJadwal.size();
    }

    @Override
    public JSONObject getItem(int i) {
        return daftarJadwal.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.list_history, viewGroup, false);
        }



        TextView tgl=view.findViewById(R.id.tgl);
        TextView pelajaran=view.findViewById(R.id.pelajaran);
        TextView hari=view.findViewById(R.id.hari);


        try
        {

            JSONObject ob=daftarJadwal.get(i);
            tgl.setText(ob.getString("Tanggal"));
            pelajaran.setText(ob.getString("NamaKelas"));
            hari.setText(ob.getString("shari"));
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            System.out.println("error");
        }


        return view;
    }
}

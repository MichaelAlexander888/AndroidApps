package project.android.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.TextView;

public class MenuUtamaActivity extends AppCompatActivity {

    TextView tvWelcome;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_utama);
        tvWelcome=(TextView)findViewById(R.id.tvWelcome);
        try {
            tvWelcome.setText("Welcome "+Util.user.getString("Nama")+" "+Util.user.getString("NRP"));
        }
        catch (Exception ex)
        {

        }

        getSupportActionBar().hide();

    }

    public void generate(View v)
    {
        Intent it=new Intent(MenuUtamaActivity.this,CubeActivity.class);
        startActivity(it);
    }

    public void lihatprofile(View v)
    {
        Intent it=new Intent(MenuUtamaActivity.this,HistoryActivity.class);
        startActivity(it);
    }

    public void logout(View v)
    {
        MenuUtamaActivity.this.finish();
    }

}

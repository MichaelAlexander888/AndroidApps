package project.android.myapplication;

/**
 * Created by Evelyn Joy on 22/03/2018.
 */


public interface AsyncResponse {
    public void execute(String s);
}
